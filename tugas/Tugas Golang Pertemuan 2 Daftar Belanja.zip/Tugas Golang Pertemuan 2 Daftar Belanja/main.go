//Nama: Naufal Ridho Permana
//NIM: 2404130075

package main
import "fmt"


type Item struct {
	Nama   string
	Harga  float64
	Jumlah int
}

func TambahItem(daftar *[]Item, nama string, harga float64, jumlah int) error {
	
	if harga <= 0 {
		return fmt.Errorf("gagal menambah '%s': harga harus lebih dari 0", nama)
	}
	if jumlah <= 0 {
		return fmt.Errorf("gagal menambah '%s': jumlah harus lebih dari 0", nama)
	}

	newItem := Item{
		Nama:   nama,
		Harga:  harga,
		Jumlah: jumlah,
	}
	

	*daftar = append(*daftar, newItem)
	fmt.Printf("Tambah item: %s (%d pcs)\n", nama, jumlah)
	return nil
}

func HitungTotal(daftar []Item) float64 {
	var total float64 = 0
	for _, item := range daftar {
		total += item.Harga * float64(item.Jumlah)
	}
	return total
}

func Tampilkan(daftar []Item) {
	fmt.Println("\n=== Daftar Belanja ===")
	if len(daftar) == 0 {
		fmt.Println("Daftar belanja masih kosong.")
		return
	}

	for i, item := range daftar {
		subtotal := item.Harga * float64(item.Jumlah)
		fmt.Printf("%d. %s\n", i+1, item.Nama)
		fmt.Printf("   %d x Rp%.0f = Rp%.0f\n", item.Jumlah, item.Harga, subtotal)
	}
	
	fmt.Println()
	fmt.Printf("Total Keseluruhan: Rp%.0f\n", HitungTotal(daftar))
}

func main() {
	
	var daftarBelanja = []Item{}

	
	TambahItem(&daftarBelanja, "Beras", 15000, 5)
	TambahItem(&daftarBelanja, "Minyak Goreng", 35000, 2)

	
	err := TambahItem(&daftarBelanja, "Gula", 0, 2)
	if err != nil {
		fmt.Println("Error:", err)
	}

	Tampilkan(daftarBelanja)
}